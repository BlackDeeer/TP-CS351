#include <stdio.h>

/*
Ensemble de triplet à tester:
(24, 36, 12)
(221, 782, 17)
(1078, 322, 14)
(252,360,36)


*/

int PGCD(int a, int b)
{
    // Division euclidienne pour trouver le PGCD 
    int r, r_avant;
    r = 0;
    
    while(b != 0)
    {
        r_avant = r;
        r = a % b;
        a = b;
        b = r;
    }
    
    return(r_avant);
}

int main()
{
    int a,b,r;
    printf("Entrez les valeurs des deux valeurs entieres: \n");

    scanf("%d",&a);
    scanf("%d",&b);

    r = PGCD(a,b);
    printf("%d",r);
    return(0);
    

}