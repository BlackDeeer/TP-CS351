#include <stdio.h>
#include <stdlib.h>


void afficherNotes (float Notes[], int n);
float minimumNotes( float Notes[], int n);
float maximumNotes( float Notes[], int n);
float calculeMoyenne(float Notes[], int n);
float calculeVariance(float Notes[], int n);
float calculeEcartType(float Notes[], int n);
int rechercherValeur(float Notes[], int n, float valeur);